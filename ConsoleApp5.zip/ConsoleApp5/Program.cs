﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

using System;

public class CPU
{
    private string manufacturer;
    private string model;
    private int clockSpeed;
    private string socket;
    private int powerDraw;

    // Constructor that accepts all parameters
    public CPU(string manufacturer, string model, int clockSpeed, string socket, int powerDraw)
    {
        Manufacturer = manufacturer;
        Model = model;
        ClockSpeed = clockSpeed;
        Socket = socket;
        PowerDraw = powerDraw;
    }

    // Overloaded constructor without manufacturer
    public CPU(string model, int clockSpeed, string socket, int powerDraw)
        : this(string.Empty, model, clockSpeed, socket, powerDraw)
    {
    }

    // Property validation
    public string Manufacturer
    {
        get => manufacturer;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentOutOfRangeException(nameof(Manufacturer), "Manufacturer cannot be null or empty.");
            manufacturer = value.Trim();
        }
    }

    public string Model
    {
        get => model;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentOutOfRangeException(nameof(Model), "Model cannot be null or empty.");
            model = value.Trim();
        }
    }

    public int ClockSpeed
    {
        get => clockSpeed;
        set
        {
            if (value < 0)
                throw new ArgumentOutOfRangeException(nameof(ClockSpeed), "Clock Speed cannot be negative.");
            clockSpeed = value;
        }
    }

    public string Socket
    {
        get => socket;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentOutOfRangeException(nameof(Socket), "Socket cannot be null or empty.");
            socket = value.Trim();
        }
    }

    public int PowerDraw
    {
        get => powerDraw;
        set
        {
            if (value < 0)
                throw new ArgumentOutOfRangeException(nameof(PowerDraw), "Power Draw cannot be negative.");
            powerDraw = value;
        }
    }

    public override string ToString()
    {
        return $"{Manufacturer} {Model}\n" +
               $"Clock Speed: {ClockSpeed} MHz\n" +
               $"Socket: {Socket}\n" +
               $"Power Draw: {PowerDraw} Watt";
    }
}








public abstract class Computer
{
    private string manufacturer;
    private CPU cpu;

    // Constructor to initialize Computer with Manufacturer and CPU
    public Computer(string manufacturer, CPU cpu)
    {
        Manufacturer = manufacturer;
        CPU = cpu;
    }

    // Property validation
    public string Manufacturer
    {
        get => manufacturer;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentOutOfRangeException(nameof(Manufacturer), "Manufacturer cannot be null or empty.");
            manufacturer = value.Trim();
        }
    }

    public CPU CPU
    {
        get => cpu;
        set
        {
            if (value == null)
                throw new ArgumentOutOfRangeException(nameof(CPU), "CPU cannot be null.");
            cpu = value;
        }
    }

    // Abstract method to calculate the total power draw (TDP)
    public abstract int CalcTDP();

    public override string ToString()
    {
        return $"Manufacturer: {Manufacturer}\nCPU: {CPU.ToString()}";
    }
}







public class Laptop : Computer
{
    private string laptopModel;
    private int fixedTDP;

    // Constructor to initialize Laptop with Manufacturer, Model, CPU, and fixed TDP
    public Laptop(string manufacturer, string laptopModel, CPU cpu, int fixedTDP)
        : base(manufacturer, cpu)
    {
        LaptopModel = laptopModel;
        this.fixedTDP = fixedTDP;
    }

    // Property validation for LaptopModel
    public string LaptopModel
    {
        get => laptopModel;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentOutOfRangeException(nameof(LaptopModel), "Laptop Model cannot be null or empty.");
            laptopModel = value.Trim();
        }
    }

    // Override CalcTDP to return fixed TDP
    public override int CalcTDP()
    {
        return fixedTDP;
    }

    public override string ToString()
    {
        return $"Manufacturer: {Manufacturer}\nLaptop Model: {LaptopModel}\nCPU: {CPU.ToString()}\nFixed TDP: {CalcTDP()} Watt";
    }
}